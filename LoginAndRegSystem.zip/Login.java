/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.loginandregsystem;


public class Login {
    
    public static boolean checkUserName(){
    boolean val = false;
    return val;
    };
    
    public static String registerUser(){
    String message = "Complexity";
    return message;
    };
    
    public static boolean LoginUser(){
    boolean val = false;
    return val;
    };
    
    public static String returnLoginStatus(){
    String message = "Registered";
    return message;
    };
    
}
