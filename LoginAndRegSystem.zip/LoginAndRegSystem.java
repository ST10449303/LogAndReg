/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.loginandregsystem;

import java.util.Scanner;


public class LoginAndRegSystem {

    public static void main(String[] args) {
        System.out.println("Enter username ");
    }
    
    private static boolean checkUserName(String[] args){
        Scanner userInput = new Scanner(System.in);
        
        String username, firstname, surname;
        
        
        
        System.out.println("Enter username: ");
        username = userInput.nextLine();
        System.out.println("Enter firstname: ");
        firstname = userInput.nextLine();
        System.out.println("Enter surname: ");
        surname = userInput.nextLine();
        
        if(username.equals("Kayi_") && (firstname.equals("Thabelo")) && (surname.equals("Mahada"))){
            return true;
        } else {
            System.out.println("Invalid username, firstname or surname");
            return false;
        }
          
    }
    
}
